-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2023 at 09:04 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `address`, `email`, `phone`, `firstname`, `lastname`, `pass`) VALUES
(13, 'j28/2,', 'tioss.infor@gmail.com', '774186332', 'sasindu', 'bandara', '123'),
(14, 'j28/2, weligalla rd, godagama, mawanella', 'sasindulakshithabandara@gmail.com', '774186332', 'saman', 'tha', '123'),
(15, 'test address road', 'c@gmail.com', '774186335', 'test', 'Customer', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `position` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `position`, `firstname`, `lastname`, `pass`) VALUES
(8, 'ceo', 'as', 'as', ''),
(10, 'admin', 'samantha', 'mamantha', 'abc'),
(11, 'worker', 'sas', 'ban', 'worker'),
(13, 'ceo', 'jam', 'jam', '123'),
(14, 'admin', 'admin', 'test', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE `material` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `material`
--

INSERT INTO `material` (`Id`, `name`, `weight`, `quantity`) VALUES
(3, 'Liberica', 50, 22),
(4, 'Excelsa', 56, 50),
(5, 'Robusta', 45, 20);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `cid` int(11) NOT NULL,
  `cname` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `pname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `date`, `cid`, `cname`, `status`, `pname`) VALUES
(5, '2023-05-06', 12, '', 'done', 'Arabica'),
(6, '2023-05-06', 12, '', 'waiting', 'Excelsa'),
(9, '2023-05-06', 13, '', 'waiting', 'Excelsa'),
(10, '2023-05-06', 13, '', 'waiting', 'Excelsa'),
(11, '2023-05-06', 13, '', 'waiting', 'Excelsa'),
(12, '2023-05-06', 14, '', 'waiting', 'Excelsa'),
(13, '2023-05-06', 14, '', 'waiting', 'Excelsa'),
(14, '2023-05-06', 13, '', 'waiting', 'Excelsa'),
(15, '2023-05-06', 13, '', 'waiting', 'Excelsa'),
(16, '2023-05-06', 13, '', 'waiting', 'Excelsa'),
(17, '2023-05-06', 13, '', 'waiting', 'Excelsa'),
(18, '2023-05-06', 15, 'test', 'waiting', 'Excelsa');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Id`, `name`, `des`, `quantity`, `price`) VALUES
(6, 'Excelsa', '5kg', 500, '3500.00'),
(7, 'Excelsa', '1kg', 120, '100.00'),
(8, 'Excelsa', '1kg', 120, '100.00'),
(9, 'Excelsa', '1kg', 120, '560.00'),
(11, 'Excelsa', '1kg', 120, '100.00'),
(12, 'Excelsa', '1kg', 120, '100.00'),
(13, 'Excelsa', '1kg', 120, '100.00'),
(15, 'Excelsa', '1kg', 120, '100.00'),
(16, 'Excelsa', '1kg', 120, '100.00'),
(17, 'Excelsa', '1kg', 120, '100.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `material`
--
ALTER TABLE `material`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
